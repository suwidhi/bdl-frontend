import { Box, Flex, Stat, StatArrow, StatGroup, StatHelpText, StatLabel, StatNumber, Text, VStack } from '@chakra-ui/react'
import React from 'react'

function Report() {
    return (
        <VStack padding="1rem" alignItems="flex-start" spacing="2rem">
            <VStack margin="0 1rem 1rem 0">
                <Text alignSelf="flex-start" color="gray.900" fontSize="lg">Sales Trend</Text>
                <StatGroup width="24rem" bgColor="gray.100" color="gray.700" padding="2rem">
                    <Stat>
                        <StatLabel>First</StatLabel>
                        <StatNumber>345,670</StatNumber>
                        <StatHelpText>
                        <StatArrow type="increase" />
                        23.36%
                        </StatHelpText>
                    </Stat>

                    <Stat>
                        <StatLabel>Second</StatLabel>
                        <StatNumber>45</StatNumber>
                        <StatHelpText>
                        <StatArrow type="decrease" />
                        9.05%
                        </StatHelpText>
                    </Stat>

                    <Stat>
                        <StatLabel>Third</StatLabel>
                        <StatNumber>45</StatNumber>
                        <StatHelpText>
                        <StatArrow type="decrease" />
                        9.05%
                        </StatHelpText>
                    </Stat>
                </StatGroup>
            </VStack>

            <VStack margin="0 1rem 1rem 0">
                <Text alignSelf="flex-start" color="gray.900" fontSize="lg">Sales Trend</Text>
                <StatGroup width="24rem" bgColor="gray.100" color="gray.700" padding="2rem">
                    <Stat>
                        <StatLabel>First</StatLabel>
                        <StatNumber>345,670</StatNumber>
                        <StatHelpText>
                        <StatArrow type="increase" />
                        23.36%
                        </StatHelpText>
                    </Stat>

                    <Stat>
                        <StatLabel>Second</StatLabel>
                        <StatNumber>45</StatNumber>
                        <StatHelpText>
                        <StatArrow type="decrease" />
                        9.05%
                        </StatHelpText>
                    </Stat>

                    <Stat>
                        <StatLabel>Third</StatLabel>
                        <StatNumber>45</StatNumber>
                        <StatHelpText>
                        <StatArrow type="decrease" />
                        9.05%
                        </StatHelpText>
                    </Stat>
                </StatGroup>
            </VStack>

            <VStack margin="0 1rem 1rem 0">
                <Text alignSelf="flex-start" color="gray.900" fontSize="lg">Sales Trend</Text>
                <StatGroup width="24rem" bgColor="gray.100" color="gray.700" padding="2rem">
                    <Stat>
                        <StatLabel>First</StatLabel>
                        <StatNumber>345,670</StatNumber>
                        <StatHelpText>
                        <StatArrow type="increase" />
                        23.36%
                        </StatHelpText>
                    </Stat>

                    <Stat>
                        <StatLabel>Second</StatLabel>
                        <StatNumber>45</StatNumber>
                        <StatHelpText>
                        <StatArrow type="decrease" />
                        9.05%
                        </StatHelpText>
                    </Stat>

                    <Stat>
                        <StatLabel>Third</StatLabel>
                        <StatNumber>45</StatNumber>
                        <StatHelpText>
                        <StatArrow type="decrease" />
                        9.05%
                        </StatHelpText>
                    </Stat>
                </StatGroup>
            </VStack>

            <VStack margin="0 1rem 1rem 0">
                <Text alignSelf="flex-start" color="gray.900" fontSize="lg">Sales Trend</Text>
                <StatGroup width="24rem" bgColor="gray.100" color="gray.700" padding="2rem">
                    <Stat>
                        <StatLabel>First</StatLabel>
                        <StatNumber>345,670</StatNumber>
                        <StatHelpText>
                        <StatArrow type="increase" />
                        23.36%
                        </StatHelpText>
                    </Stat>

                    <Stat>
                        <StatLabel>Second</StatLabel>
                        <StatNumber>45</StatNumber>
                        <StatHelpText>
                        <StatArrow type="decrease" />
                        9.05%
                        </StatHelpText>
                    </Stat>

                    <Stat>
                        <StatLabel>Third</StatLabel>
                        <StatNumber>45</StatNumber>
                        <StatHelpText>
                        <StatArrow type="decrease" />
                        9.05%
                        </StatHelpText>
                    </Stat>
                </StatGroup>
            </VStack>

            <VStack margin="0 1rem 1rem 0">
                <Text alignSelf="flex-start" color="gray.900" fontSize="lg">Sales Trend</Text>
                <StatGroup width="24rem" bgColor="gray.100" color="gray.700" padding="2rem">
                    <Stat>
                        <StatLabel>First</StatLabel>
                        <StatNumber>345,670</StatNumber>
                        <StatHelpText>
                        <StatArrow type="increase" />
                        23.36%
                        </StatHelpText>
                    </Stat>

                    <Stat>
                        <StatLabel>Second</StatLabel>
                        <StatNumber>45</StatNumber>
                        <StatHelpText>
                        <StatArrow type="decrease" />
                        9.05%
                        </StatHelpText>
                    </Stat>

                    <Stat>
                        <StatLabel>Third</StatLabel>
                        <StatNumber>45</StatNumber>
                        <StatHelpText>
                        <StatArrow type="decrease" />
                        9.05%
                        </StatHelpText>
                    </Stat>
                </StatGroup>
            </VStack>
        </VStack>
    )
}

export default Report
