import React from 'react'
import {
    Table,
    Thead,
    Tbody,
    Tr,
    Th,
    Td,
    Button,
    Badge,
  } from '@chakra-ui/react';
import DeleteDialog from '../components/DeleteDialog';

import apiClient from '../services/api';
import { Context } from '../Store'

function TransactionView({ dataset, deleteCallback, updateForm, openFormCallback }) {

    const [brands, setBrands] = React.useState([])
    const [cars, setCars] = React.useState([])
    const [dealers, setDealers] = React.useState([])
    const [employees, setEmployees] = React.useState([])
    const [transactionTypes, setTransactionTypes] = React.useState([])
    const [individuals, setIndividuals] = React.useState([])
    const [companies, setCompanies] = React.useState([])
    const [statuses, setStatuses] = React.useState([])

    const [state, dispatch] = React.useContext(Context)
    const config = {
        headers: {
            'Content-Type' : 'application/json',
            'Authorization': 'Bearer ' + state.token
        }
    }
    React.useEffect(function(){
        fetchAll('brands', setBrands)
        fetchAll('cars', setCars)
        fetchAll('dealers', setDealers)
        fetchAll('employees', setEmployees)
        fetchAll('transactiontypes', setTransactionTypes)
        fetchAll('individualcustomers', setIndividuals)
        fetchAll('companycustomers', setCompanies)
        fetchAll('transactionstatuses', setStatuses)
    }, [])

    const fetchAll = (name, setter) => {
        apiClient.get('/api/' + name, config)
        .then(response => {
            setter(response.data)
        }).catch(error => {})
    }

    const findColor = (status) => {
        console.log(status)
        switch(status){
            case 'Waiting':
                return 'yellow';
            case 'On Progress':
                return 'blue';
            case 'Verified':
                return 'green';
            case 'Completed':
                return 'gray';
            default:
                return 'black'
        }
    }

    return (
        <Table variant="striped" textColor="gray.700" colorScheme="blackAlpha" size="md">
            <Thead>
            <Tr>
                {
                    dataset.head.map(function(head){
                        return(
                            <Th>{head}</Th>
                        )
                    })
                }
                <Th>Options</Th>
            </Tr>
            </Thead>
            <Tbody fontSize="sm">
                {
                    dataset.body.map(function(item){
                        return(
                            <Tr>
                                <Td>
                                    {
                                        cars.map(function(car){
                                            if(car.vin == item.vehicle){
                                                return(
                                                    car.name
                                                )
                                            }
                                        })
                                    }
                                </Td>
                                <Td>
                                    {
                                        dealers.map(function(dealer){
                                            if(dealer.id === item.dealer){
                                                return(
                                                    dealer.name
                                                )
                                            }
                                        })
                                    }
                                </Td>
                                <Td>
                                    {
                                        employees.map(function(employee){
                                            if(employee.id === item.employee){
                                                return(
                                                    employee.name
                                                )
                                            }
                                        })
                                    }
                                </Td>
                                <Td>
                                    {
                                        transactionTypes.map(function(type){
                                            if(type.id === item.type){
                                                return(
                                                    type.name
                                                )
                                            }
                                        })
                                    }
                                </Td>
                                <Td>
                                    {
                                        individuals.map(function(customer){
                                            if(customer.id === item.customer){
                                                return(
                                                    customer.name
                                                )
                                            }
                                        })
                                    }
                                </Td>
                                <Td>
                                    {
                                        companies.map(function(company){
                                            if(company.id === item.company){
                                                return(
                                                    company.name
                                                )
                                            }
                                        })
                                    }
                                </Td>
                                <Td>
                                    {
                                        statuses.map(function(status){
                                            if(status.id === item.status){
                                                return(
                                                    <Badge colorScheme={findColor(status.name)}>
                                                    { status.name }
                                                    </Badge>
                                                )
                                            }
                                        })
                                    }
                                </Td>
                                <Td>{ item.created_at }</Td>
                                <Td width="14rem">
                                <Button colorScheme="gray" leftIcon={<i className="la la-edit"></i>} onClick={() => {
                                    openFormCallback(item)
                                }} size="xs" marginRight=".5rem" >Edit</Button>
                                    <DeleteDialog item={item} callback={deleteCallback} />
                                </Td>
                            </Tr>
                        )
                    })
                }
            </Tbody>
        </Table>
    )
}

export default TransactionView
