import { FormControl, FormErrorMessage, FormLabel, VStack, Input, Select } from '@chakra-ui/react'
import React from 'react'

import apiClient from '../services/api';
import { Context } from '../Store'


function CarForm({ error, data }) {
    const [state, dispatch] = React.useContext(Context)
    
    const [models, setModels] = React.useState([])

    React.useEffect(function(){
        fetchAll('carmodels', setModels)
    }, [])

    const config = {
        headers: {
            'Content-Type' : 'application/json',
            'Authorization': 'Bearer ' + state.token
        }
    }
    const fetchAll = (name, setter) => {
        apiClient.get('/api/' + name, config)
        .then(response => {
            setter(response.data)
        })
    }
    
    return (
        <>
            <VStack spacing="1rem">

            <FormControl id="model" size="sm" isInvalid={error['model']}>
                <FormLabel size="sm">Car Model</FormLabel>
                <Select name="model">
                    {models.map(function(model){
                        return(
                            <option selected={data.model == model.id} value={model.id}>{model.name}</option>
                        )
                    })}
                </Select>
                <FormErrorMessage>{error['model']}</FormErrorMessage>
            </FormControl>

            <FormControl id="name" size="sm" isInvalid={error['engine']}>
                <FormLabel size="sm">Engine</FormLabel>
                <Input name="engine" defaultValue={data.engine && data.engine} size="sm"/>
                <FormErrorMessage>{error['engine']}</FormErrorMessage>
            </FormControl>
            
            <FormControl id="color" size="sm" isInvalid={error['color']}>
                <FormLabel size="sm">Color</FormLabel>
                <Input name="color" defaultValue={data.color && data.color} size="sm"/>
                <FormErrorMessage>{error['color']}</FormErrorMessage>
            </FormControl>

            <FormControl id="transmission" size="sm" isInvalid={error['transmission']}>
                <FormLabel size="sm">Transmission</FormLabel>
                <Input name="transmission" defaultValue={data.transmission && data.transmission} size="sm"/>
                <FormErrorMessage>{error['transmission']}</FormErrorMessage>
            </FormControl>
            </VStack>
        </>
    )
}

export default CarForm
