import { FormControl, FormErrorMessage, FormLabel, VStack, Input, Select, Badge } from '@chakra-ui/react'
import React from 'react'

import { Context } from '../Store'
import apiClient from '../services/api';

function TransactionForm({ error, data }) {
    
    const [brands, setBrands] = React.useState([])
    const [cars, setCars] = React.useState([])
    const [dealers, setDealers] = React.useState([])
    const [employees, setEmployees] = React.useState([])
    const [transactionTypes, setTransactionTypes] = React.useState([])
    const [individuals, setIndividuals] = React.useState([])
    const [companies, setCompanies] = React.useState([])
    const [statuses, setStatuses] = React.useState([])

    React.useEffect(function(){
        fetchAll('brands', setBrands)
        fetchAll('cars', setCars)
        fetchAll('dealers', setDealers)
        fetchAll('employees', setEmployees)
        fetchAll('transactiontypes', setTransactionTypes)
        fetchAll('individualcustomers', setIndividuals)
        fetchAll('companycustomers', setCompanies)
        fetchAll('transactionstatuses', setStatuses)
    }, [])
    
    const [state, dispatch] = React.useContext(Context)
    const config = {
        headers: {
            'Content-Type' : 'application/json',
            'Authorization': 'Bearer ' + state.token
        }
    }
    const fetchAll = (name, setter) => {
        apiClient.get('/api/' + name, config)
        .then(response => {
            setter(response.data)
        })
    }
    
    return (
        <>
            <VStack spacing="1rem">

            <FormControl id="vehicle" size="sm" isInvalid={error['vehicle']}>
                <FormLabel size="sm">Vehicle</FormLabel>
                <Select name="vehicle">
                    {cars.map(function(car){
                        return(
                            <option selected={data.car === car.vin} value={car.vin}>{car.vin} - {car.name}</option>
                        )
                    })}
                </Select>
                <FormErrorMessage>{error['vehicle']}</FormErrorMessage>
            </FormControl>

            <FormControl id="dealer" size="sm" isInvalid={error['dealer']}>
                <FormLabel size="sm">Dealer</FormLabel>
                <Select name="dealer">
                    {dealers.map(function(dealer){
                        return(
                            <option selected={data.dealer == dealer.id} value={dealer.id}>{dealer.name}</option>
                        )
                    })}
                </Select>
                <FormErrorMessage>{error['dealer']}</FormErrorMessage>
            </FormControl>

            <FormControl id="employee" size="sm" isInvalid={error['employee']}>
                <FormLabel size="sm">Admin</FormLabel>
                <Select name="employee">
                    {employees.map(function(employee){
                        return(
                            <option selected={data.employee == employee.id} value={employee.id}>{employee.name}</option>
                        )
                    })}
                </Select>
                <FormErrorMessage>{error['employee']}</FormErrorMessage>
            </FormControl>

            <FormControl id="type" size="sm" isInvalid={error['type']}>
                <FormLabel size="sm">Transaction Type</FormLabel>
                <Select name="type">
                    {transactionTypes.map(function(type){
                        return(
                            <option selected={data.type == type.id} value={type.id}>{type.name}</option>
                        )
                    })}
                </Select>
                <FormErrorMessage>{error['type']}</FormErrorMessage>
            </FormControl>

            <FormControl id="customer" size="sm" isInvalid={error['customer']}>
                <FormLabel size="sm">Individual Customer</FormLabel>
                <Select name="customer">
                    <option value={0}>None</option>
                    {individuals.map(function(individual){
                        return(
                            <option selected={data.customer == individual.id} value={individual.id}>{individual.name}</option>
                        )
                    })}
                </Select>
                <FormErrorMessage>{error['customer']}</FormErrorMessage>
            </FormControl>

            <FormControl id="company" size="sm" isInvalid={error['company']}>
                <FormLabel size="sm">Company Customer</FormLabel>
                <Select name="company">
                    <option value={0}>None</option>
                    {companies.map(function(company){
                        return(
                            <option selected={data.company == company.id} value={company.id}>{company.name}</option>
                        )
                    })}
                </Select>
                <FormErrorMessage>{error['company']}</FormErrorMessage>
            </FormControl>

            <FormControl id="status" size="sm" isInvalid={error['status']}>
                <FormLabel size="sm">Transaction Status</FormLabel>
                <Select name="status">
                    {statuses.map(function(status){
                        return(
                            <option selected={data.status == status.id} value={status.id}>{ status.name }</option>
                        )
                    })}
                </Select>
                <FormErrorMessage>{error['status']}</FormErrorMessage>
            </FormControl>

            </VStack>
        </>
    )
}

export default TransactionForm
