import { FormControl, FormErrorMessage, FormLabel, VStack, Input, Select } from '@chakra-ui/react'
import React from 'react'

import apiClient from '../services/api';
import { Context } from '../Store'


function CarForm({ error, data }) {
    const [state, dispatch] = React.useContext(Context)
    
    const [cars, setCars] = React.useState([])

    React.useEffect(function(){
        fetchAll('cars', setCars)
    }, [])

    const config = {
        headers: {
            'Content-Type' : 'application/json',
            'Authorization': 'Bearer ' + state.token
        }
    }

    const fetchAll = (name, setter) => {
        apiClient.get('/api/' + name, config)
        .then(response => {
            setter(response.data)
        })
    }
    
    return (
        <>
            <VStack spacing="1rem">

            <FormControl id="car" size="sm" isInvalid={error['car']}>
                <FormLabel size="sm">Car</FormLabel>
                <Select name="car">
                    {cars.map(function(car){
                        return(
                            <option selected={data.car === car.vin} value={car.vin}>{car.name}</option>
                        )
                    })}
                </Select>
                <FormErrorMessage>{error['car']}</FormErrorMessage>
            </FormControl>

            <FormControl id="name" size="sm" isInvalid={error['name']}>
                <FormLabel size="sm">Model Name</FormLabel>
                <Input name="name" defaultValue={data.name && data.name} size="sm"/>
                <FormErrorMessage>{error['name']}</FormErrorMessage>
            </FormControl>
            
            <FormControl id="description" size="sm" isInvalid={error['description']}>
                <FormLabel size="sm">Description</FormLabel>
                <Input name="description" defaultValue={data.description && data.description} size="sm"/>
                <FormErrorMessage>{error['description']}</FormErrorMessage>
            </FormControl>
            </VStack>
        </>
    )
}

export default CarForm
