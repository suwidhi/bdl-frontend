import React from 'react';
import {
  ChakraProvider,
} from '@chakra-ui/react';

import { Context } from './Store'
import { Route } from 'react-router-dom'
import Main from './Main';
import Login from './Login';
import Register from './Register';

function App() {

  const [state, dispatch] = React.useContext(Context)

  return (
    <ChakraProvider>
      {
        state.token !== "" ? <Main /> : window.location.pathname !== '/register' && <Login />
      }

      <Route path="/register">
        <Register />
      </Route>

      <Route path="/login">
        <Login />
      </Route>

    </ChakraProvider>
  );
}

export default App;
